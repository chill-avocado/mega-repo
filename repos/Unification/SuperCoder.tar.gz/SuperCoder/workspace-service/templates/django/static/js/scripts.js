document.addEventListener('DOMContentLoaded', function() {
    console.log('JavaScript loaded and ready.');
    // Add more JavaScript functionality here
});