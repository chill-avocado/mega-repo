export interface SidebarOption {
  id: string;
  text: string;
  selected: string;
  unselected: string;
  route: string;
}
