export interface ModelsList {
  model_name: string;
  api_key: string;
  text?: string;
  icon?: string;
}
