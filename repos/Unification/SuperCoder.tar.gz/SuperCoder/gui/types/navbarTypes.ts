export interface NavbarTypes {
  id: string;
  text: string;
  image: string;
  url: string;
}
