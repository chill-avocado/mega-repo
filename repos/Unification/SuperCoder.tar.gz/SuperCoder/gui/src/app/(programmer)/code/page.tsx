export default function Code() {
  return null;
}
