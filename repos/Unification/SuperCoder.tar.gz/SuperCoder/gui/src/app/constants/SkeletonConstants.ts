export const SkeletonTypes = {
  PROJECT: 'project',
  WORKBENCH: 'workbench',
  CODE: 'code',
  BOARD: 'board',
  PULL_REQUEST: 'pull_request',
};
