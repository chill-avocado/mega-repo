export const ActivityLogType = {
    ERROR: 'ERROR',
    CODE: 'CODE',
    INFO: 'INFO',
}