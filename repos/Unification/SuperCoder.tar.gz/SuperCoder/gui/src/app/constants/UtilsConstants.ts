export const Servers = {
  BACKEND: 'backend',
  FRONTEND: 'frontend',
};
