import LandingPage from '@/components/HomeComponents/LandingPage';

export default function Home() {
  return (
    <div id={'home'}>
      <LandingPage />
    </div>
  );
}
