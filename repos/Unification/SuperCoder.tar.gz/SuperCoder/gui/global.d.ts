interface Window {
  clarity: (action: string, key: string, value: string | null) => void;
}
