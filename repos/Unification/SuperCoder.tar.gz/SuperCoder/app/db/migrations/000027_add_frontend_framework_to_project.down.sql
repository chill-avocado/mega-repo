ALTER TABLE projects
DROP COLUMN frontend_framework;
