ALTER TABLE stories
DROP COLUMN frontend_url,
DROP COLUMN url,
DROP COLUMN hash_id,
DROP COLUMN review_viewed;