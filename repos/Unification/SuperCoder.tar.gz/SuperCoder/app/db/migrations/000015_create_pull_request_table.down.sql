DROP TABLE pull_requests;
