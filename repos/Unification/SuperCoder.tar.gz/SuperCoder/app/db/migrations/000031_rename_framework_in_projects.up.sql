-- Rename Framework to BackendFramework
ALTER TABLE projects
RENAME COLUMN framework TO backend_framework;