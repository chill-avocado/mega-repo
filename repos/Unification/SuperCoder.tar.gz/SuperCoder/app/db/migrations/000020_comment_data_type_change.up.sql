ALTER TABLE pull_request_comments
ALTER COLUMN comment TYPE TEXT;