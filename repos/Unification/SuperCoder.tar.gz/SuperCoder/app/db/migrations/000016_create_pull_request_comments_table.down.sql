DROP TABLE pull_request_comments;
