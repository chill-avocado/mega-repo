ALTER TABLE stories
DROP COLUMN "type";
