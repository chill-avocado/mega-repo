DROP TABLE IF EXISTS story_instructions;
