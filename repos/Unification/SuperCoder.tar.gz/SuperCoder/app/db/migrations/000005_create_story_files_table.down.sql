DROP TABLE IF EXISTS story_files;
