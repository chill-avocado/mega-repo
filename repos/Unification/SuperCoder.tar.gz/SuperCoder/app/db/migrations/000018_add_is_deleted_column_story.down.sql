ALTER TABLE stories
DROP COLUMN is_deleted;