DROP INDEX IF EXISTS idx_activity_logs_type;

DROP TABLE IF EXISTS activity_logs;
