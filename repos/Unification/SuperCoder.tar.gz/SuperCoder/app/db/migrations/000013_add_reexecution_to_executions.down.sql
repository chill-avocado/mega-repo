ALTER TABLE executions DROP COLUMN re_execution;
