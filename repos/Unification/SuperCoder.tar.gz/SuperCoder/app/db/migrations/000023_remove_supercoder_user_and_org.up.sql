DELETE FROM users WHERE id = 1;
DELETE FROM organisations WHERE id = 1;