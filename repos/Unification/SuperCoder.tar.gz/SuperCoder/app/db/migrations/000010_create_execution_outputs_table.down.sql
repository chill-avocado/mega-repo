DROP TABLE IF EXISTS execution_outputs;
