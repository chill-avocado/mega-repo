ALTER TABLE execution_outputs DROP COLUMN pull_request_id;
