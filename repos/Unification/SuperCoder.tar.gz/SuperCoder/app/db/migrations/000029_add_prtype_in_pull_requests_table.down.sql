ALTER TABLE pull_requests
DROP COLUMN pr_type;
