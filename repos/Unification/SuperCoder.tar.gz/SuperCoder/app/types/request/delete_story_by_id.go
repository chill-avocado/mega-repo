package request

type DeleteStoryByID struct {
	StoryID int `json:"story_id"`
}
