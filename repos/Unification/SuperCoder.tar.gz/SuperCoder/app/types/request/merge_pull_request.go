package request

type MergePullRequest struct {
	PullRequestID int `json:"pull_request_id"`
}
