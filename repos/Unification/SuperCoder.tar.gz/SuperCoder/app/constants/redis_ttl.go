package constants

import "time"

const (
	ProjectConnectionTTL = 6 * time.Hour
)
