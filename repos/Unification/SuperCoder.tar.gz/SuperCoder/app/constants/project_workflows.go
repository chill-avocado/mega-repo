package constants

const (
	Flask  = "flask"
	NextJs = "nextjs"
)
