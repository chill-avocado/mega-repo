package constants

const (
	CreateExecutionJobTaskType   = "create:job"
	DeleteWorkspaceTaskType      = "delete:workspace"
	CheckExecutionStatusTaskType = "check:execution_status"
)
