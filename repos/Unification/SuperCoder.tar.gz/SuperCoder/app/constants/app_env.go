package constants

const (
	Production  = "production"
	Development = "development"
)
