package constants

const (
	Open   = "OPEN"
	Close  = "CLOSE"
	Merged = "MERGED"
)
