package constants

const (
	GPT_4O        = "gpt-4o"
	GPT_3_5_Turbo = "gpt-3.5-turbo"
	GPT_3_5       = "gpt-3.5"
	CLAUDE_3      = "claude-3"
)
