package constants

const (
    Backend  = "backend"
    Frontend = "frontend"
)