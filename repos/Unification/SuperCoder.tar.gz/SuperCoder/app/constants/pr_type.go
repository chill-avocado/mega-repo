package constants

const (
	Automated = "automated"
	Manual    = "manual"
)
