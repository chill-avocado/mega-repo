package constants

const (
	LOCAL = "local"
	S3    = "s3"
)