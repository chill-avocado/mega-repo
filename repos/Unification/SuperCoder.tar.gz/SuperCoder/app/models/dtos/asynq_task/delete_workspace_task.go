package asynq_task

type CreateDeleteWorkspaceTaskPayload struct {
	WorkspaceID string `json:"workspace_id"`
}
