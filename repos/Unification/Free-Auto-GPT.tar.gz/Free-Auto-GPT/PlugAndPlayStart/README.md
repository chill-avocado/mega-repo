
For any problem open an ISSUE 🚬, the project is very simple so any help is welcome💸.

**Are you bored reading😴? Do you want to try our project now⏳? Open the notebook on Colab everything is ready!** 

**RUN NOW ON COLAB 😮👉** [![Open in Colab](https://colab.research.google.com/assets/colab-badge.svg)](https://colab.research.google.com/drive/14854fi6oO4lXqR3_mt6tc2Lr2IsA12oq?usp=sharing)
