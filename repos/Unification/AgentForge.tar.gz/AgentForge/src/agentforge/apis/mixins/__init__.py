"""
Mixins for API adapters with additional capabilities.
""" 